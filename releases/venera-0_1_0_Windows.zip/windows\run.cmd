@echo off
setlocal
cd /d "%~dp0source"
if not exist "target\release\venera.exe" (
  echo venera: binary not found, building release...
  call "%~dp0build.cmd"
  if errorlevel 1 exit /b 1
)
"target\release\venera.exe" %*
