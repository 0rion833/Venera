@echo off
setlocal
cd /d "%~dp0source"
cargo fetch --locked
if errorlevel 1 exit /b 1
cargo build --release --locked
if errorlevel 1 exit /b 1
echo.
echo Built: %CD%\target\release\venera.exe
