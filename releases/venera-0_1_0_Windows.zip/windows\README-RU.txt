VENERA 0.1.0 · ПОРТАТИВНАЯ СБОРКА
=================================

Состав
------
linux/           source/ + build.sh + run.sh + MANUAL-RU.txt + MANUAL-EN.txt
macos/           source/ + build.sh + run.sh + MANUAL-RU.txt + MANUAL-EN.txt
windows/         venera.exe + source/ + build.cmd + run.cmd
README-RU.txt    этот файл
README-EN.txt    то же на английском
PLAN-RU.txt      план портирования и проверки

Одна кодовая база
-----------------
В linux/, macos/ и windows/ лежат одинаковые исходники — каждый каталог
самодостаточен. Отдельных «linux-версии» и «mac-версии» кода нет: один и тот же
код собирается на всех трёх ОС, различия закрыты cfg-ветками:
- пути и verbatim-префикс Windows;
- bash-инструмент: cmd /C на Windows, /bin/sh -c на Unix;
- файлы настройки в домашнем каталоге пользователя;
- темы и языки лежат внутри src/ и встраиваются в бинарник.

Быстрый старт
-------------
Windows:
    windows\venera.exe
    # или: windows\run.cmd

Linux:
    cd linux
    sh run.sh        # соберёт при необходимости и запустит

macOS:
    cd macos
    sh run.sh        # то же на macOS

Собрать без запуска:
    cd linux && sh build.sh
    cd macos && sh build.sh
    windows\build.cmd

Вручную (любая ОС):
    cd <platform>/source
    cargo fetch --locked
    cargo build --release --locked
    target/release/venera

Первый запуск
-------------
Venera создаёт конфиг и просит мастер-пароль для хранилища ключей.
Ключ провайдера добавляется в TUI командой /api.
Команды index, map, measure, search, outline, cat работают офлайн,
без API-ключа и без сети.

Пути и проекты
--------------
- Запусти бинарник из каталога проекта или введи в TUI:
      /project /home/user/my-project
- /project принимает:
      абсолютный путь;
      путь в кавычках ("D:\My Project");
      путь относительно текущего проекта.
- Enter открывает каталог, Esc закрывает диалог.
- Если путь неверный, диалог не закрывается: ошибка видна прямо в нём.
- Пути в выводе печатаются без Windows-префикса \\?\.

Проверки
--------
Из каталога linux/source, macos/source или windows/source:
    cargo test --locked
    cargo clippy --all-targets --locked -- -D warnings
    cargo fmt --all -- --check

Тесты не требуют сети и API-ключа.

Лицензия и данные
-----------------
Ключи хранятся только локально в зашифрованном виде.
Индекс проекта лежит в .venera/ внутри проекта.
