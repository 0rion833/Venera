VENERA 0.1.0 · PORTABLE BUILD
=============================

Contents
--------
linux/           source/ + build.sh + run.sh + MANUAL-RU.txt + MANUAL-EN.txt
macos/           source/ + build.sh + run.sh + MANUAL-RU.txt + MANUAL-EN.txt
windows/         venera.exe + source/ + build.cmd + run.cmd
README-RU.txt    Russian readme
README-EN.txt    this file
PLAN-RU.txt      porting and verification plan

One codebase
------------
linux/, macos/, and windows/ contain the same sources; each directory is
self-contained. There is no separate "Linux fork" or "Mac fork": one codebase
builds on all three systems, and differences are isolated behind cfg branches:
- Windows paths and the verbatim prefix;
- the bash tool: cmd /C on Windows, /bin/sh -c on Unix;
- config files under the user's home directory;
- themes and languages live inside src/ and are embedded into the binary.

Quick start
-----------
Windows:
    windows\venera.exe
    # or: windows\run.cmd

Linux:
    cd linux
    sh run.sh        # builds if needed, then runs

macOS:
    cd macos
    sh run.sh        # same on macOS

Build without running:
    cd linux && sh build.sh
    cd macos && sh build.sh
    windows\build.cmd

Manually (any OS):
    cd <platform>/source
    cargo fetch --locked
    cargo build --release --locked
    target/release/venera

First launch
------------
Venera creates a config and asks for a master password for the encrypted key vault.
Add a provider key in the TUI with /api.
index, map, measure, search, outline, and cat work offline,
without an API key and without network access.

Paths and projects
------------------
- Start the binary from a project directory or type in the TUI:
      /project /home/user/my-project
- /project accepts:
      an absolute path;
      a quoted path ("D:\My Project");
      a path relative to the current project.
- Enter opens the directory; Esc closes the dialog.
- A bad path keeps the dialog open and shows the error inside it.
- Printed paths never include the Windows \\?\ prefix.

Checks
------
From linux/source, macos/source, or windows/source:
    cargo test --locked
    cargo clippy --all-targets --locked -- -D warnings
    cargo fmt --all -- --check

The tests need no network and no API key.

License and data
----------------
Keys are stored locally and encrypted.
The project index lives in .venera/ inside the project.
