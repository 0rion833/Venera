#!/bin/sh
# Build if needed, then run Venera. Arguments are passed through.
set -eu
cd "$(dirname "$0")/source"
if [ ! -x target/release/venera ]; then
    echo "venera: binary not found, building release..."
    cargo fetch --locked
    cargo build --release --locked
fi
exec ./target/release/venera "$@"
