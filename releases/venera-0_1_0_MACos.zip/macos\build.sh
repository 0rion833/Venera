#!/bin/sh
# Build Venera on macOS. Run: sh build.sh
set -eu
cd "$(dirname "$0")/source"
cargo fetch --locked
cargo build --release --locked
printf '\nBuilt: %s\n' "$PWD/target/release/venera"
